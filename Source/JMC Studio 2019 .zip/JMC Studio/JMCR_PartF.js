// Get the elements
var all = document.getElementsByClassName("portfolio-row-all");
var music = document.getElementsByClassName("portfolio-row-music");
var lifestyle = document.getElementsByClassName("portfolio-row-lifestyle");
var gaming = document.getElementsByClassName("portfolio-row-gaming");

// Declare a loop variable
var i;

// Display only "portfolio-row-all"
function all1() {
    for (i = 0; i < all.length; i++) {
        all[i].style.display = "flex";
        music[i].style.display = "none";
        lifestyle[i].style.display = "none";
        gaming[i].style.display = "none";
    }
}

// Display only "portfolio-row-music"
function music1() {
    for (i = 0; i < music.length; i++) {
        music[i].style.display = "flex";
        all[i].style.display = "none";
        lifestyle[i].style.display = "none";
        gaming[i].style.display = "none";
    }
}

// Display only "portfolio-row-lifestyle"
function lifestyle1() {
    for (i = 0; i < lifestyle.length; i++) {
        lifestyle[i].style.display = "flex";
        music[i].style.display = "none";
        all[i].style.display = "none";
        gaming[i].style.display = "none";
    }
}

// Display only "portfolio-row-gaming"
function gaming1() {
    for (i = 0; i < gaming.length; i++) {
        gaming[i].style.display = "flex";
        music[i].style.display = "none";
        lifestyle[i].style.display = "none";
        all[i].style.display = "none";
    }
}