// Get the elements
var eas = document.getElementsByClassName("tabcontent_eas");
var em = document.getElementsByClassName("tabcontent_em");
var cs = document.getElementsByClassName("tabcontent_cs");

// Declare a loop variable
var i;

// Display only "tabcontent_eas"
function eas1() {
    for (i = 0; i < all.length; i++) {
        eas[i].style.display = "table";
        em[i].style.display = "none";
        cs[i].style.display = "none";
    }
}

// Display only "tabcontent_em"
function em1() {
    for (i = 0; i < music.length; i++) {
        em[i].style.display = "table";
        eas[i].style.display = "none";
        cs[i].style.display = "none";
    }
}

// Display only "tabcontent_cs"
function cs1() {
    for (i = 0; i < lifestyle.length; i++) {
        cs[i].style.display = "table";
        eas[i].style.display = "none";
        em[i].style.display = "none";
    }
}