Open Robot with below steps:

TryAss(1) > TryAss > Debug > GP Bot.exe